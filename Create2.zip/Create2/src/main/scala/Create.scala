import org.apache.spark.graphx.Graph
import org.apache.spark.sql.Row
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.SQLContext
import org.apache.spark.graphx._
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types._

object Create2
{
  def main(args: Array[String])
  {
    val conf= new SparkConf().setAppName("Create2").setMaster("local")   
	  val spark = SparkSession.builder().appName("SparkSessionZipsExample").config(conf).getOrCreate()
    val sqlContext = spark.sqlContext
    val sc = spark.sparkContext
        val customSchema = StructType(Array(StructField("id", LongType, true),StructField("name", StringType, true),StructField("profession", StringType, true)))

        val vertices = sqlContext.read.format("csv").option("delimiter", ",").option("header", "true").schema(customSchema).load("test.csv")

        class Concept(var id: Long, 
                      var name: String,
                      var profession: String 
                      ) extends Serializable


        var v= Array((vertices.take(1).last.getLong(0), (vertices.take(1).last.getString(1), vertices.take(1).last.getString(2))))
        var v2= Array((vertices.take(2).last.getLong(0), (vertices.take(2).last.getString(1), vertices.take(2).last.getString(2))))
        v= Array.concat(v,v2)
        for (i <- 3 to vertices.count.toInt)
        {
            println(i)
            v2=Array((vertices.take(i).last.getLong(0), (vertices.take(i).last.getString(1), vertices.take(i).last.getString(2))))
            v= Array.concat(v,v2)
        }

        val users: RDD[(VertexId, (String,String))] =sc.parallelize(v)
        val relationships: RDD[Edge[String]] =
                        sc.parallelize
                        (
                          Array
                          (
                            Edge
                            (
                              3L, 7L, "collab"
                            )
                            
                            ,    Edge(5L, 3L, "advisor"),
                                Edge(2L, 5L, "colleague"), Edge(5L, 7L, "pi")
                          )
                        )
        
        val graph = Graph(users, relationships)
        graph.vertices.foreach(println)
        graph.edges.foreach(println)



	
  }

}

