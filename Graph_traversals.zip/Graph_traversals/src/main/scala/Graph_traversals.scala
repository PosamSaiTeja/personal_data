import scalax.collection.edge.WDiEdge
import scalax.collection.edge.Implicits._


import org.graphframes.GraphFrame
import org.apache.spark.graphx.Graph
import org.apache.spark.sql.Row
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext._
import org.apache.spark.sql.SparkSession


object Graph_traversals
{
  def main(args: Array[String])
  {

	

     val conf= new SparkConf()
        .setAppName("Read_file")
	.setMaster("local")
    

	val spark = SparkSession.builder().appName("SparkSessionZipsExample")
		.config(conf)
		.getOrCreate()




	
	val fc1 = g.findCycle
	print(fc1)
         // Some(Cycle(3, 3~>4, 4, 4~>2, 2, 2~>3, 3))
	//val fc2 = (g get 4).findCycle // Some(Cycle(4, 4~>2, 2, 2~>3, 3, 3~>4, 4))
	 
	//for (c1 <- fc1; c2 <- fc2) yield c1 == c2     // false
	//for (c1 <- fc1; c2 <- fc2) yield c1 sameAs c2 // true
	 
	//g.findCycleContaining(g get 1)             pa   // None

 }

}

