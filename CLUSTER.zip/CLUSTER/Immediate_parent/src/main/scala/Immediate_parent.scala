import org.apache.spark.graphx.Graph
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.graphx._
import org.apache.spark.rdd.RDD

object Immediate_parent
{
  def main(args: Array[String])
  {
    val conf= new SparkConf().setAppName("Immediate_parent").setMaster("local")   
	val spark = SparkSession.builder().appName("SparkSessionZipsExample").config(conf).getOrCreate()
    //val sqlContext = spark.sqlContext
    val sc = spark.sparkContext
    //creating class
    class Concept(var id: Long, 
              var active: Integer,
              var definitionStatusId: Long ,
              var effectiveTime: Long,
              var moduleId : Long,
              var check: Boolean
              ) extends Serializable
    
    val concepts: RDD[(VertexId, (Concept))] = sc.textFile("concept_csv.csv").zipWithIndex.filter(p => p._2 > 0).map(p => p._1).map(line => line.split(",")).filter(arr => arr(0).length > 0).map(n => (n(0).toLong,new Concept(n(0).toLong,n(1).toInt,n(2).toLong,n(3).toLong,n(4).toLong,false))).filter(x => (x._2.active == 1))
    //val concepts = sc.objectFile[(org.apache.spark.graphx.VertexId, Concept)]("concepts_object")

    class Relationships(
                        var src: Long, 
                        var dst: Long,
                        var id: Long,
                        var effectiveTime: Long,
                        var active: Integer,
                        var moduleId: Long,
                        var relationshipGroup: Long,
                        var typeId: Long,
                        var characteristicTypeId: Long,
                        var modifierId: Long
                      ) extends Serializable


    var relationships: RDD[Edge[Relationships]]  =sc.textFile("rel_csv.csv").zipWithIndex.filter(p => p._2 > 0).map(p => p._1).map(line => line.split(",")).filter(arr => arr(0).length > 0).map(n => Edge(n(0).toLong,n(1).toLong,new Relationships(n(0).toLong,n(1).toLong,n(2).toLong,n(3).toLong,n(4).toInt,n(5).toLong,n(6).toLong,n(7).toLong,n(8).toLong,n(9).toLong))).filter({ case Edge(src, dst, prop) => prop.active==1 && prop.typeId==116680003})

    var t1 = System.currentTimeMillis
    var x=relationships.filter { case Edge(src, dst, prop) => prop.src==720252008L}.map({case Edge(src,dst,prop)=>prop.dst})
    println(" for the id ",720252008L)
    x.collect().foreach(println)
    println("The count is:",x.count())
    var t2 = System.currentTimeMillis
    print("TIME TAKEN :")
    println((t2 - t1) + " msecs")
    println("--------------------------------------------------------------------------------------")




    t1 = System.currentTimeMillis
    x=relationships.filter { case Edge(src, dst, prop) => prop.src== 57809008L}.map({case Edge(src,dst,prop)=>prop.dst})
    println(" for the id ", 57809008L)
    x.collect().foreach(println)
    println("The count is:",x.count())
    t2 = System.currentTimeMillis
    print("TIME TAKEN :")
    println((t2 - t1) + " msecs")
    println("--------------------------------------------------------------------------------------")



    t1 = System.currentTimeMillis
    x=relationships.filter { case Edge(src, dst, prop) => prop.src==301122000L}.map({case Edge(src,dst,prop)=>prop.dst})
    println(" for the id ",301122000L)
    x.collect().foreach(println)
    println("The count is:",x.count())
    t2 = System.currentTimeMillis
    print("TIME TAKEN :")
    println((t2 - t1) + " msecs")
    println("--------------------------------------------------------------------------------------")



    t1 = System.currentTimeMillis
    x=relationships.filter { case Edge(src, dst, prop) => prop.src==22298006L}.map({case Edge(src,dst,prop)=>prop.dst})
    println(" for the id ",22298006L)
    x.collect().foreach(println)
    println("The count is:",x.count())
    t2 = System.currentTimeMillis
    print("TIME TAKEN :")
    println((t2 - t1) + " msecs")
    println("--------------------------------------------------------------------------------------")


    t1 = System.currentTimeMillis
    x=relationships.filter { case Edge(src, dst, prop) => prop.src==279192003L}.map({case Edge(src,dst,prop)=>prop.dst})
    println(" for the id ",279192003L)
    x.collect().foreach(println)
    println("The count is:",x.count())
    t2 = System.currentTimeMillis
    print("TIME TAKEN :")
    println((t2 - t1) + " msecs")
    println("--------------------------------------------------------------------------------------")

  }

}