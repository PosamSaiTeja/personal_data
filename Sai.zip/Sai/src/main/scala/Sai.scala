import org.graphframes.GraphFrame
import org.apache.spark.graphx.Graph
import org.apache.spark.sql.Row
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext._
import org.apache.spark.sql.SparkSession
object Sai
{
  def main(args: Array[String])
  {

	

     val conf= new SparkConf().setAppName("Sai").setMaster("local")
    

	val spark = SparkSession.builder().appName("Sai").config(conf).getOrCreate()



	//val concept = spark.read.option("header", "true").csv("file:///home/msc2/concept_csv.csv")
	val concept = spark.read.option("header", "true").csv("file:///home/saiteja/SAI/Data/concept_csv.csv")
	//val concept = spark.read.option("header", "true").csv("hdfs:///snomed/Terminology_csv_files/sct2_Concept_Snapshot_INT_20190131.txt")
	println(concept.show(20, false))

	val rel = spark.read.option("header", "true").csv("file:///home/saiteja/SAI/Data/rel_csv.csv")
	//val rel = spark.read.option("header", "true").csv("file:///home/msc2/rel_csv.csv")
	println(rel.show(30, false))
	
	val g = GraphFrame(concept,rel)
	println("graph frame got created")
	val gx: Graph[Row, Row] = g.toGraphX
	println("converted into graphx graph")
	println("Number of vertices",gx.numVertices)
	println("Number of relations",gx.numEdges)
	
	//println(page_rank)
	//  hdfs:///csv/file/dir/file.csv
	//println(x)
	//gx.vertices.collect.foreach(println(_))
	
  }

}

