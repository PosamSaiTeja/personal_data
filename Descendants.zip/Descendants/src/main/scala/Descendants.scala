import org.apache.spark.graphx.Graph
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.graphx._
import org.apache.spark.rdd.RDD
object Descendants
{
  def main(args: Array[String])
  {
  val conf= new SparkConf().setAppName("Descendants").setMaster("local")   
	val spark = SparkSession.builder().appName("SparkSessionZipsExample").config(conf).getOrCreate()
    //val sqlContext = spark.sqlContext
    val sc = spark.sparkContext
    //creating class
    class Concept(var id: Long, 
              var active: Integer,
              var definitionStatusId: Long ,
              var effectiveTime: Long,
              var moduleId : Long,
              var check: Boolean
              ) extends Serializable
    
    val concepts: RDD[(VertexId, (Concept))] = sc.textFile("concept_csv.csv").zipWithIndex.filter(p => p._2 > 0).map(p => p._1).map(line => line.split(",")).filter(arr => arr(0).length > 0).map(n => (n(0).toLong,new Concept(n(0).toLong,n(1).toInt,n(2).toLong,n(3).toLong,n(4).toLong,false))).filter(x => (x._2.active == 1))
    //val concepts = sc.objectFile[(org.apache.spark.graphx.VertexId, Concept)]("concepts_object")

    class Relationships(
                        var src: Long, 
                        var dst: Long,
                        var id: Long,
                        var effectiveTime: Long,
                        var active: Integer,
                        var moduleId: Long,
                        var relationshipGroup: Long,
                        var typeId: Long,
                        var characteristicTypeId: Long,
                        var modifierId: Long
                      ) extends Serializable


    var relationships: RDD[Edge[Relationships]]  =sc.textFile("rel_csv.csv").zipWithIndex.filter(p => p._2 > 0).map(p => p._1).map(line => line.split(",")).filter(arr => arr(0).length > 0).map(n => Edge(n(0).toLong,n(1).toLong,new Relationships(n(0).toLong,n(1).toLong,n(2).toLong,n(3).toLong,n(4).toInt,n(5).toLong,n(6).toLong,n(7).toLong,n(8).toLong,n(9).toLong))).filter({ case Edge(src, dst, prop) => prop.active==1 && prop.typeId==116680003})

    var t1 = System.currentTimeMillis
    var v1 = concepts.map(x => {if(x._2.id == 720252008L) {x._2.check=true; x} else x})
    var count = v1.filter(x => (x._2.check)).map(x => x._2.id).count()
    var prev_count = 0L;
    while(prev_count != count)
    {
        var graph = Graph(v1,relationships)
        v1 = graph.aggregateMessages[Boolean](ed => {ed.sendToSrc(ed.dstAttr.check)}, {_ || _}).rightOuterJoin(graph.vertices).map(x => {if(!x._2._2.check) x._2._2.check=x._2._1.getOrElse(false); (x._1,x._2._2)})
        prev_count = count;
        count = v1.filter(x => (x._2.check)).map(x => x._2.id).count()
    }
    println("For the id ",720252008L)
    var x= v1.filter(x => (x._2.check)).map(x => x._2.id).collect()
    //x.foreach(println)
    println("Total number of descendants",x.length-1)
    var t2 = System.currentTimeMillis
    print("TIME TAKEN :")
    println((t2 - t1) + " msecs")
    println("--------------------------------------------------------------------")

 //relationships =sc.textFile("rel_csv.csv").zipWithIndex.filter(p => p._2 > 0).map(p => p._1).map(line => line.split(",")).filter(arr => arr(0).length > 0).map(n => Edge(n(0).toLong,n(1).toLong,new Relationships(n(0).toLong,n(1).toLong,n(2).toLong,n(3).toLong,n(4).toInt,n(5).toLong,n(6).toLong,n(7).toLong,n(8).toLong,n(9).toLong))).filter({ case Edge(src, dst, prop) => prop.active==1 && prop.typeId==116680003})

    t1 = System.currentTimeMillis
    v1 = concepts.map(x => {if(x._2.id == 57809008L) {x._2.check=true; x} else x})
     count = v1.filter(x => (x._2.check)).map(x => x._2.id).count()
     prev_count = 0L;
    while(prev_count != count)
    {
        var graph = Graph(v1,relationships)
        v1 = graph.aggregateMessages[Boolean](ed => {ed.sendToSrc(ed.dstAttr.check)}, {_ || _}).rightOuterJoin(graph.vertices).map(x => {if(!x._2._2.check) x._2._2.check=x._2._1.getOrElse(false); (x._1,x._2._2)})
        prev_count = count;
        count = v1.filter(x => (x._2.check)).map(x => x._2.id).count()
    }
    println("For the id ",57809008L)

     x= v1.filter(x => (x._2.check)).map(x => x._2.id).collect()
    //x.foreach(println)
    println("Total number of descendants",x.length-1)
    t2 = System.currentTimeMillis
    print("TIME TAKEN :")
    println((t2 - t1) + " msecs")
    println("--------------------------------------------------------------------")



//relationships =sc.textFile("rel_csv.csv").zipWithIndex.filter(p => p._2 > 0).map(p => p._1).map(line => line.split(",")).filter(arr => arr(0).length > 0).map(n => Edge(n(0).toLong,n(1).toLong,new Relationships(n(0).toLong,n(1).toLong,n(2).toLong,n(3).toLong,n(4).toInt,n(5).toLong,n(6).toLong,n(7).toLong,n(8).toLong,n(9).toLong))).filter({ case Edge(src, dst, prop) => prop.active==1 && prop.typeId==116680003})

    t1 = System.currentTimeMillis
    v1 = concepts.map(x => {if(x._2.id == 301122000L) {x._2.check=true; x} else x})
     count = v1.filter(x => (x._2.check)).map(x => x._2.id).count()
     prev_count = 0L;
    while(prev_count != count)
    {
        var graph = Graph(v1,relationships)
        v1 = graph.aggregateMessages[Boolean](ed => {ed.sendToSrc(ed.dstAttr.check)}, {_ || _}).rightOuterJoin(graph.vertices).map(x => {if(!x._2._2.check) x._2._2.check=x._2._1.getOrElse(false); (x._1,x._2._2)})
        prev_count = count;
        count = v1.filter(x => (x._2.check)).map(x => x._2.id).count()
    }
    println("For the id ",301122000L)

     x= v1.filter(x => (x._2.check)).map(x => x._2.id).collect()
    //x.foreach(println)
    println("Total number of descendants",x.length-1)
    t2 = System.currentTimeMillis
    print("TIME TAKEN :")
    println((t2 - t1) + " msecs")
    println("--------------------------------------------------------------------")

//relationships =sc.textFile("rel_csv.csv").zipWithIndex.filter(p => p._2 > 0).map(p => p._1).map(line => line.split(",")).filter(arr => arr(0).length > 0).map(n => Edge(n(0).toLong,n(1).toLong,new Relationships(n(0).toLong,n(1).toLong,n(2).toLong,n(3).toLong,n(4).toInt,n(5).toLong,n(6).toLong,n(7).toLong,n(8).toLong,n(9).toLong))).filter({ case Edge(src, dst, prop) => prop.active==1 && prop.typeId==116680003})

    t1 = System.currentTimeMillis
    v1 = concepts.map(x => {if(x._2.id == 22298006L) {x._2.check=true; x} else x})
     count = v1.filter(x => (x._2.check)).map(x => x._2.id).count()
     prev_count = 0L;
    while(prev_count != count)
    {
        var graph = Graph(v1,relationships)
        v1 = graph.aggregateMessages[Boolean](ed => {ed.sendToSrc(ed.dstAttr.check)}, {_ || _}).rightOuterJoin(graph.vertices).map(x => {if(!x._2._2.check) x._2._2.check=x._2._1.getOrElse(false); (x._1,x._2._2)})
        prev_count = count;
        count = v1.filter(x => (x._2.check)).map(x => x._2.id).count()
    }
    println("For the id ",22298006L)

     x= v1.filter(x => (x._2.check)).map(x => x._2.id).collect()
    //x.foreach(println)
    println("Total number of descendants",x.length-1)
    t2 = System.currentTimeMillis
    print("TIME TAKEN :")
    println((t2 - t1) + " msecs")
    println("--------------------------------------------------------------------")



//relationships =sc.textFile("rel_csv.csv").zipWithIndex.filter(p => p._2 > 0).map(p => p._1).map(line => line.split(",")).filter(arr => arr(0).length > 0).map(n => Edge(n(0).toLong,n(1).toLong,new Relationships(n(0).toLong,n(1).toLong,n(2).toLong,n(3).toLong,n(4).toInt,n(5).toLong,n(6).toLong,n(7).toLong,n(8).toLong,n(9).toLong))).filter({ case Edge(src, dst, prop) => prop.active==1 && prop.typeId==116680003})

    t1 = System.currentTimeMillis
    v1 = concepts.map(x => {if(x._2.id == 16439801000119108L) {x._2.check=true; x} else x})
     count = v1.filter(x => (x._2.check)).map(x => x._2.id).count()
     prev_count = 0L;
    while(prev_count != count)
    {
        var graph = Graph(v1,relationships)
        v1 = graph.aggregateMessages[Boolean](ed => {ed.sendToSrc(ed.dstAttr.check)}, {_ || _}).rightOuterJoin(graph.vertices).map(x => {if(!x._2._2.check) x._2._2.check=x._2._1.getOrElse(false); (x._1,x._2._2)})
        prev_count = count;
        count = v1.filter(x => (x._2.check)).map(x => x._2.id).count()
    }
    println("For the id ",16439801000119108L)

     x= v1.filter(x => (x._2.check)).map(x => x._2.id).collect()
    //x.foreach(println)
    println("Total number of descendants",x.length-1)
    t2 = System.currentTimeMillis
    print("TIME TAKEN :")
    println((t2 - t1) + " msecs")
    println("--------------------------------------------------------------------")

//relationships =sc.textFile("rel_csv.csv").zipWithIndex.filter(p => p._2 > 0).map(p => p._1).map(line => line.split(",")).filter(arr => arr(0).length > 0).map(n => Edge(n(0).toLong,n(1).toLong,new Relationships(n(0).toLong,n(1).toLong,n(2).toLong,n(3).toLong,n(4).toInt,n(5).toLong,n(6).toLong,n(7).toLong,n(8).toLong,n(9).toLong))).filter({ case Edge(src, dst, prop) => prop.active==1 && prop.typeId==116680003})

    t1 = System.currentTimeMillis
    v1 = concepts.map(x => {if(x._2.id == 138875005L) {x._2.check=true; x} else x})
     count = v1.filter(x => (x._2.check)).map(x => x._2.id).count()
     prev_count = 0L;
    while(prev_count != count)
    {
        var graph = Graph(v1,relationships)
        v1 = graph.aggregateMessages[Boolean](ed => {ed.sendToSrc(ed.dstAttr.check)}, {_ || _}).rightOuterJoin(graph.vertices).map(x => {if(!x._2._2.check) x._2._2.check=x._2._1.getOrElse(false); (x._1,x._2._2)})
        prev_count = count;
        count = v1.filter(x => (x._2.check)).map(x => x._2.id).count()
    }
    println("For the id ",138875005L)

     x= v1.filter(x => (x._2.check)).map(x => x._2.id).collect()
    //x.foreach(println)
    println("Total number of descendants",x.length-1)
    t2 = System.currentTimeMillis
    print("TIME TAKEN :")
    println((t2 - t1) + " msecs")
    println("--------------------------------------------------------------------")


  }

}