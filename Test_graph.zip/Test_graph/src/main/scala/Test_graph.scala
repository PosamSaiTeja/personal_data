import org.graphframes.GraphFrame
import org.apache.spark.graphx.Graph
import org.apache.spark.sql.Row
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext._
import org.apache.spark.sql.SparkSession
object Read_file
{
  def main(args: Array[String])
  {

	

     val conf= new SparkConf()
        .setAppName("Read_file")
	.setMaster("local")
    

	val spark = SparkSession.builder().appName("SparkSessionZipsExample")
		.config(conf)
		.getOrCreate()



	val concept = spark.read.option("header", "true").csv("file:///home/msc2/3rd_Sem/project/spark-programs/Test_graph/src/main/scala/concepts.csv")
	//val concept = spark.read.option("header", "true").csv("hdfs:///snomed/Terminology_csv_files/sct2_Concept_Snapshot_INT_20190131.txt")
	println(concept.show(20, false))

	val rel = spark.read.option("header", "true").csv("file:///home/msc2/3rd_Sem/project/spark-programs/Test_graph/src/main/scala/relations.csv")
	println(rel.show(20, false))
	
	val g = GraphFrame(concept,rel)
	println("graph frame got created")
	val gx: Graph[Row, Row] = g.toGraphX
	println("converted into graphx graph")
	println("Number of vertices",gx.numVertices)
	println("Number of relations",gx.numEdges)
	val page_rank= gx.pageRank(0.01).vertices
	
	
	page_rank.collect.foreach(println(_))
	//  hdfs:///csv/file/dir/file.csv
	//println(x)
	//gx.vertices.collect.foreach(println(_))
	
  }

}

