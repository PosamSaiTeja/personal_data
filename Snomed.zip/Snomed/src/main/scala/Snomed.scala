import org.apache.spark.graphx.Graph
import org.apache.spark.sql.Row
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.SQLContext
import org.apache.spark.graphx._
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types._

object Snomed
{
  def main(args: Array[String])
  {
    val conf= new SparkConf().setAppName("Snomed").setMaster("local")   
	  val spark = SparkSession.builder().appName("SparkSessionZipsExample").config(conf).getOrCreate()
    val sqlContext = spark.sqlContext
    val sc = spark.sparkContext
    //creating class
    class Concept(var id: Long, 
              var active: Integer,
              var definitionStatusId: Long ,
              var effectiveTime: Long,
              var moduleId : Long
                            
              ) extends Serializable


    //schema for concepts
    val customSchema_ver = StructType(Array(StructField("id", LongType, true),
                                    StructField("active", IntegerType, true),
                                    StructField("definitionStatusId", LongType, true),
                                    StructField("effectiveTime", LongType, true),
                                    StructField("moduleId", LongType, true)
                                    )
                              )

    //concept_test.csv is the name of the subset
    //concept_csv.csv  is the name of full set
    val vertices = sqlContext.read.format("csv").option("delimiter", ",").option("header", "true").schema(customSchema_ver).load("concept_csv.csv")
    var v4=Array((vertices.take(2).last.getLong(0),new Concept(vertices.take(2).last.getLong(0),vertices.take(2).last.getInt(1),vertices.take(2).last.getLong(2),vertices.take(2).last.getLong(3),vertices.take(2).last.getLong(4)) ))
    var v3=Array((vertices.take(1).last.getLong(0),new Concept(vertices.take(1).last.getLong(0),vertices.take(1).last.getInt(1),vertices.take(1).last.getLong(2),vertices.take(1).last.getLong(3),vertices.take(1).last.getLong(4)) ))

    for (i <- 2 to vertices.count.toInt)
            {
                println(i)
                //val p1=new Concept(vertices.take(1).last.getLong(0),vertices.take(1).last.getLong(1),vertices.take(1).last.getLong(2),vertices.take(1).last.getLong(3),vertices.take(1).last.getLong(4))
                v4=Array((vertices.take(i).last.getLong(0),new Concept(vertices.take(i).last.getLong(0),vertices.take(i).last.getInt(1),vertices.take(i).last.getLong(2),vertices.take(i).last.getLong(3),vertices.take(i).last.getLong(4)) ))
                v3= Array.concat(v3,v4)
            }
         val concepts: RDD[(VertexId, (Concept))] =sc.parallelize(v3)
          concepts.saveAsObjectFile("concept_object")

      //concepts: org.apache.spark.rdd.RDD[(org.apache.spark.graphx.VertexId, Concept)] = ParallelCollectionRDD[69] at parallelize at <console>:41
        //var x= concepts.filter { case (id, (c)) => c.id == 100000000 }.count
        //println(x)
        //var all =concepts.filter { case (id, (c)) => c.effectiveTime == 20020131 }
        //all.collect().foreach(println)
    






    //schema for relationships
    val customSchema_rel = StructType(Array(StructField("src", LongType, true),
                                            StructField("dst", LongType, true),
                                            StructField("id", LongType, true),
                                            StructField("effectiveTime", LongType, true),
                                            StructField("active", IntegerType, true),
                                            StructField("moduleId", LongType, true),
                                            StructField("relationshipGroup", LongType, true),
                                            StructField("typeId", LongType, true),
                                            StructField("characteristicTypeId", LongType, true),
                                            StructField("modifierId", LongType, true)
                                        )
                                  )



    class Relationships(
                        var src: Long, 
                        var dst: Long,
                        var id: Long,
                        var effectiveTime: Long,
                        var active: Integer,
                        var moduleId: Long,
                        var relationshipGroup: Long,
                        var typeId: Long,
                        var characteristicTypeId: Long,
                        var modifierId: Long
                      ) extends Serializable

//relations_test.csv is the name of the subset
    // rel_csv.csv  is the name of full set
        val relations = sqlContext.read.format("csv").option("delimiter", ",").option("header", "true").schema(customSchema_rel).load("relations_test.csv")

    //never keep the values in the constructor in different different lines

    //var sai = new Relationships(relations.take(1).last.getLong(0),relations.take(1).last.getLong(1),relations.take(1).last.getLong(2),relations.take(1).last.getLong(3),relations.take(1).last.getInt(4),relations.take(1).last.getLong(5),relations.take(1).last.getLong(6),relations.take(1).last.getLong(7),relations.take(1).last.getLong(8),relations.take(1).last.getLong(9))
      

            
      var v6= Array(Edge(relations.take(1).last.getLong(0),relations.take(1).last.getLong(1),new Relationships(relations.take(1).last.getLong(0),relations.take(1).last.getLong(1),relations.take(1).last.getLong(2),relations.take(1).last.getLong(3),relations.take(1).last.getInt(4),relations.take(1).last.getLong(5),relations.take(1).last.getLong(6),relations.take(1).last.getLong(7),relations.take(1).last.getLong(8),relations.take(1).last.getLong(9))))
      var v7= Array(Edge(relations.take(2).last.getLong(0),relations.take(2).last.getLong(1),new Relationships(relations.take(2).last.getLong(0),relations.take(2).last.getLong(1),relations.take(2).last.getLong(2),relations.take(2).last.getLong(3),relations.take(2).last.getInt(4),relations.take(2).last.getLong(5),relations.take(2).last.getLong(6),relations.take(1).last.getLong(7),relations.take(2).last.getLong(8),relations.take(2).last.getLong(9))))
            for (i <- 2 to relations.count.toInt)
            {
              println(i)
                v7= Array(Edge(relations.take(i).last.getLong(0),relations.take(i).last.getLong(1),new Relationships(relations.take(i).last.getLong(0),relations.take(i).last.getLong(1),relations.take(i).last.getLong(2),relations.take(i).last.getLong(3),relations.take(i).last.getInt(4),relations.take(i).last.getLong(5),relations.take(i).last.getLong(6),relations.take(i).last.getLong(7),relations.take(i).last.getLong(8),relations.take(i).last.getLong(9))))
                v6= Array.concat(v6,v7)

            }
            
            val relationships: RDD[Edge[Relationships]] =sc.parallelize(v6)
            relationships.saveAsObjectFile("relationships_object")

      //val rdd_conc=sc.objectFile[(org.apache.spark.graphx.VertexId, Concept)]("concept_object")
      //val rdd_rel=sc.objectFile[org.apache.spark.graphx.Edge[Relationships]]("relationships_object")
      //var graph =Graph(rdd_conc,rdd_rel)
      var graph =Graph(concepts,relationships)
      var z= graph.edges.filter { case Edge(src, dst, rel) => src == 100000000 }.count
      println("the results of edges with the property src == 100000000",z)
      //graph.edges.filter { case Edge(src, dst, rel) => rel.active == 0 }.count
      //var y =graph.edges.filter { case Edge(src, dst, rel) => rel.active == 0 }
      //y.collect().foreach(println)
    //myRDD.collect().foreach(println)
    //printing in cluster
    //myRDD.take(n).foreach(println)

                               

  }

}

